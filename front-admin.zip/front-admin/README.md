
  # Admin Panel for Etransa

  This is a code bundle for Admin Panel for Etransa. The original project is available at https://www.figma.com/design/2KB0ubOgrUt1RLrs5yTqav/Admin-Panel-for-Etransa.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  