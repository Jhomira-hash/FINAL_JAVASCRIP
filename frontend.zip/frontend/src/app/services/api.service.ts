import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';

// === INTERFACES ===

export interface RutaData {
  id?: number;
  descripcion: string;
  inicio_ruta: string;
  fin_ruta: string;
  nombre_ruta: string;
  mapa: String;
}
export interface TipoEntidad {
  id_tipoEntidad: number;
  nombre_entidad: string;
}

export interface ParaderoData {
  id_paradero: number;
  nombre_paradero: string;
  ubicacion: string;
  latitud: number;
  longitud: number;
  tipoEntidad: TipoEntidad;
}
export interface estado {
  id_estado: number;
  nombre_estado: string;
}


export interface BusConductor {
  id: {
    id_bus: number;
    id_conductor: number;
  };
  fecha_inicio: string;
  fecha_fin: string | null;
}

export interface BusData {
  id_bus: number;
  placa: string;
  capacidad: number;
  horario: string;
  estado: estado;
  ruta: RutaData;
  busConductor?: BusConductor[];

}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly apiUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) { }

  //RUTAS
  getRutas(): Observable<RutaData[]> {
    return this.http.get<RutaData[]>(`${this.apiUrl}/ruta`).pipe(
      catchError((error) => {
        console.error('❌ Error obteniendo rutas:', error);

        const rutasPorDefecto: RutaData[] = [
          {
            nombre_ruta: 'R-1',
            inicio_ruta: 'Subtanjalla',
            fin_ruta: 'Casuarinas',
            descripcion: 'Ruta principal que conecta el centro con el sur de la ciudad.',
            mapa: 'Mapa de la Ruta R-1'
          },
          {
            nombre_ruta: 'R-2',
            inicio_ruta: 'Subtanjalla',
            fin_ruta: 'Tierra Prometida',
            descripcion: 'Ruta que recorre gran parte de Tierra Prometida',
            mapa: 'Mapa de la Ruta R-2'
          },
          {
            nombre_ruta: 'R-7',
            inicio_ruta: 'Guadalupe',
            fin_ruta: 'Plaza del Sol/Universidad San Luis Gonzaga',
            descripcion: 'Ruta que conecta Guadalupe con la zona centrica de Ica.',
            mapa: 'Mapa de la Ruta R-7'
          }
        ];

        return of(rutasPorDefecto);
      })
      
    );
  }

  //por id para admin
  getRutaById(id: number): Observable<RutaData | null> {
    return this.http.get<RutaData>(`${this.apiUrl}/${id}`).pipe(
      catchError((error) => {
        console.error(`❌ Error obteniendo ruta con id ${id}:`, error);
        return of(null);
      })
    );
  }


  //PARADEROS
  getParaderos(): Observable<ParaderoData[]> {
    return this.http.get<ParaderoData[]>(`${this.apiUrl}/paraderos`).pipe(
      catchError((error) => {
        console.error('❌ Error obteniendo paraderos:', error);

        const paraderosPorDefecto: ParaderoData[] = [
          {
            id_paradero: 1,
            nombre_paradero: "Universidad Tecnológica del Perú",
            ubicacion: "Calle Ayabaca",
            latitud: -14.0685,
            longitud: -75.7289,
            tipoEntidad: { id_tipoEntidad: 1, nombre_entidad: "Institución Educativa" }
          },
          {
            id_paradero: 2,
            nombre_paradero: "Centro Comercial Plaza del Sol",
            ubicacion: "Av. San Martín",
            latitud: -14.0751,
            longitud: -75.7302,
            tipoEntidad: { id_tipoEntidad: 3, nombre_entidad: "Centro Comercial" }
          },
          {
            id_paradero: 3,
            nombre_paradero: "Hospital Regional de Ica",
            ubicacion: "Av. Progreso, Ayabaca",
            latitud: -14.0852,
            longitud: -75.7403,
            tipoEntidad: { id_tipoEntidad: 2, nombre_entidad: "Centro Médico" }
          }
        ];

        return of(paraderosPorDefecto);
      })
    );
  }

  //BUSES
  getBuses(): Observable<BusData[]> {
  return this.http.get<BusData[]>(`${this.apiUrl}/buses`).pipe(
    catchError((error) => {
      console.error('❌ Error obteniendo buses:', error);

      const busesPorDefecto: BusData[] = [
  {
    id_bus: 1,
    placa: "ABC-123",
    capacidad: 20,
    horario: "08:00 - 14:00",
    estado: { id_estado: 1, nombre_estado: "Activo" },
    ruta: {
      nombre_ruta: "Ruta R1",
      descripcion: "Ruta al centro de Ica",
      inicio_ruta: "Calle Lima",
      fin_ruta: "Universidad UTP",
      mapa: "Mapa de la Ruta R1"
    }
  },
  {
    id_bus: 2,
    placa: "XYZ-789",
    capacidad: 25,
    horario: "10:00 - 16:00",
    estado: { id_estado: 2, nombre_estado: "En mantenimiento" },
    ruta: {  
      nombre_ruta: "Ruta R2",
      descripcion: "Ruta alternativa",
      inicio_ruta: "Subtanjalla",
      fin_ruta: "Tierra Prometida",
      mapa: "Mapa de la Ruta R2"
    }
  }
];


      return of(busesPorDefecto);
    })
  );
}

}


