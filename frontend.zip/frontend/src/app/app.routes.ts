import { Routes } from '@angular/router';
import { HeaderComponent } from './global/header/header.component';
import { FooterComponent } from './global/footer/footer.component';
import { InicioComponent } from './pages/inicio/inicio.component';
import { ParaderoComponent } from './pages/paradero/paradero.component';
import { RutasComponent } from './pages/rutas/rutas.component';
import { BusComponent } from './pages/bus/bus.component';
export const routes: Routes = [
    {path: 'header', component:  HeaderComponent},
    {path: 'footer', component:  FooterComponent},
    {path: 'inicio', component:  InicioComponent},
    {path: 'paradero', component:  ParaderoComponent},
    {path: 'rutas', component:  RutasComponent},
    {path: 'bus', component:  BusComponent},
    {path: '',
    redirectTo: '/inicio',
    pathMatch: 'full'},
    {
    path: '**',
    redirectTo: '/inicio'
  }

    
];
