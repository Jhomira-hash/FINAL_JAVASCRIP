import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HeaderComponent } from '../../global/header/header.component';
import { FooterComponent } from '../../global/footer/footer.component';
import { RutasComponent } from '../rutas/rutas.component';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {
  constructor(private router: Router) {}
  irRuta(): void {
      this.router.navigate(['/rutas']);
    }
    irBus(): void {
      this.router.navigate(['/bus']);
    }
    
    irParadero(): void {
      this.router.navigate(['/paradero']);
    }
}
