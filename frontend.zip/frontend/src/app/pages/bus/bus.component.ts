import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, BusData } from '../../services/api.service'; 
import { HeaderComponent } from '../../global/header/header.component';
import { FooterComponent } from '../../global/footer/footer.component';

@Component({
  selector: 'app-bus',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  template: `
    <app-header></app-header>
    <div class="buses-container">
      <aside class="sidebar">
        <h2 class="sidebar-title">Buses disponibles:</h2>

        <div *ngIf="buses.length === 0" class="loading">
          Cargando buses...
        </div>

        <div class="buses-list" *ngIf="buses.length > 0">
          <button 
            *ngFor="let bus of buses"
            class="bus-btn"
            [class.active]="busSeleccionado?.placa === bus.placa"
            (click)="seleccionarBus(bus)">
            
            <svg class="bus-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C8 2 4 2.5 4 6v9.5C4 16.88 4.39 18 6 18c0 1.66 1.34 3 3 3s3-1.34 3-3h0c0 1.66 1.34 3 3 3s3-1.34 3-3c1.61 0 2-.88 2-2.5V6c0-3.5-4-4-8-4zM9 19c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm6 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zM6 15V6h12v9H6z"/>
            </svg>
            <div class="bus-info-text">
                <span class="bus-plate">{{ bus.placa }}</span>
                <span class="bus-route">{{ bus.ruta?.nombre_ruta|| 'Sin Ruta' }}</span>
            </div>
          </button>
        </div>
      </aside>

      <main class="main-content" *ngIf="busSeleccionado; else emptyState">
        <header class="content-header">
          <svg class="header-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C8 2 4 2.5 4 6v9.5C4 16.88 4.39 18 6 18c0 1.66 1.34 3 3 3s3-1.34 3-3h0c0 1.66 1.34 3 3 3s3-1.34 3-3c1.61 0 2-.88 2-2.5V6c0-3.5-4-4-8-4zM9 19c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm6 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zM6 15V6h12v9H6z"/>
          </svg>
          <h1>Bus: {{ busSeleccionado.placa }}</h1>
        </header>

        <div class="bus-details-grid">
          <div class="bus-info">
            
            <div class="info-item">
              <span class="info-label">Ruta:</span>
              <span class="info-value">{{ busSeleccionado.ruta.nombre_ruta || 'Sin ruta' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Placa:</span>
              <span class="info-value">{{ busSeleccionado.placa }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Capacidad:</span>
              <span class="info-value">{{ busSeleccionado.capacidad }} pasajeros</span>
            </div>

            <div class="info-item">
              <span class="info-label">Horario:</span>
              <span class="info-value">{{ busSeleccionado.horario }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Estado:</span>
              <span class="info-value" 
                    [class.estado-activo]="esBusActivo(busSeleccionado)" 
                    [class.estado-inactivo]="!esBusActivo(busSeleccionado)">
                {{ busSeleccionado.estado.nombre_estado || 'Desconocido' }}
              </span>
            </div>

            <div class="info-item">
              <span class="info-label">Inicio de Ruta:</span>
              <span class="info-value">{{ busSeleccionado.ruta.inicio_ruta || 'N/A' }}</span>
            </div>

            <div class="info-item">
              <span class="info-label">Fin de Ruta:</span>
              <span class="info-value">{{ busSeleccionado.ruta.fin_ruta || 'N/A' }}</span>
            </div>

            <div class="info-item conductor-item">
              <span class="info-label">Conductor:</span>
              <span class="info-value">{{ getNombreConductor(busSeleccionado) }}</span>
            </div>
          </div>

          <div class="bus-image-container">
            <img 
              src='../../../assets/img/bus.jpg' 
              alt="Bus de transporte público"
              class="bus-image">
          </div>
        </div>
      </main>

      <ng-template #emptyState>
        <main class="main-content empty-state">
          <div class="empty-message">
            <svg class="empty-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C8 2 4 2.5 4 6v9.5C4 16.88 4.39 18 6 18c0 1.66 1.34 3 3 3s3-1.34 3-3h0c0 1.66 1.34 3 3 3s3-1.34 3-3c1.61 0 2-.88 2-2.5V6c0-3.5-4-4-8-4zM9 19c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm6 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zM6 15V6h12v9H6z"/>
            </svg>
            <p>Selecciona un bus para ver sus detalles</p>
          </div>
        </main>
      </ng-template>
    </div>
    <app-footer></app-footer>
  `,
    styles: [`
    .buses-container {
      display: flex;
      min-height: calc(100vh - 100px); /* Ajustado para dejar espacio a header/footer */
      background-color: #f5f5f5;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }

    /* ===== SIDEBAR ===== */
    .sidebar {
      width: 250px; /* Ancho ajustado para mejor visualización */
      background: linear-gradient(180deg, #00bcd4 0%, #00bcd4 100%);
      padding: 0;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      overflow-y: auto;
    }

    .sidebar-title {
      color: white;
      font-size: 18px;
      font-weight: 600;
      padding: 30px 20px 20px;
      margin: 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      position: sticky;
      top: 0;
      z-index: 10;
      background: #00bcd4;
    }

    .buses-list {
      display: flex;
      flex-direction: column;
    }

    .bus-btn {
      background: transparent;
      border: none;
      color: white;
      padding: 15px 20px;
      text-align: left;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 16px;
      font-weight: 400;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      gap: 15px;
      width: 100%;
    }
    
    .bus-info-text {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        line-height: 1.2;
    }
    
    .bus-plate {
        font-weight: 700;
        font-size: 18px;
    }

    .bus-route {
        font-size: 12px;
        opacity: 0.8;
    }

    .bus-btn:hover {
      background: rgba(255, 255, 255, 0.1);
    }

    .bus-btn.active {
      background: rgba(255, 255, 255, 0.2);
      border-left: 4px solid white;
      padding-left: 16px;
    }

    .bus-icon {
      width: 32px;
      height: 32px;
      flex-shrink: 0;
    }

    /* ===== MAIN CONTENT (No Changes Major) ===== */
    .main-content {
      flex: 1;
      padding: 0;
      background: white;
    }

    .content-header {
      background: linear-gradient(135deg, #00bcd4 0%, #00bcd4 100%);
      color: white;
      padding: 30px 50px;
      display: flex;
      align-items: center;
      gap: 20px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .header-icon {
      width: 48px;
      height: 48px;
    }

    .content-header h1 {
      margin: 0;
      font-size: 42px;
      font-weight: 300;
    }

    /* ===== BUS DETAILS GRID (No Changes Major) ===== */
    .bus-details-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 40px;
      padding: 50px;
      background: #f8f9fa;
    }

    .bus-info {
      background: white;
      padding: 40px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      display: flex;
      flex-direction: column;
      gap: 25px;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding-bottom: 20px;
      border-bottom: 1px solid #e9ecef;
    }

    .info-item:last-child {
      border-bottom: none;
      padding-bottom: 0;
    }

    .info-label {
      font-size: 14px;
      color: #6c757d;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .info-value {
      font-size: 20px;
      color: #212529;
      font-weight: 400;
    }

    .conductor-item .info-value {
      font-size: 24px;
      font-weight: 500;
      color: #2c3e50;
    }

    .estado-activo {
      color: #28a745 !important;
      font-weight: 600 !important;
    }

    .estado-inactivo {
      color: #dc3545 !important;
      font-weight: 600 !important;
    }

    /* ===== BUS IMAGE (No Changes Major) ===== */
    .bus-image-container {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .bus-image {
      width: 100%;
      height: auto;
      border-radius: 8px;
      object-fit: cover;
      max-height: 500px;
    }

    /* ===== EMPTY STATE (No Changes Major) ===== */
    .empty-state {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f8f9fa;
    }

    .empty-message {
      text-align: center;
      color: #6c757d;
    }

    .empty-icon {
      width: 120px;
      height: 120px;
      opacity: 0.3;
      margin-bottom: 20px;
    }

    .empty-message p {
      font-size: 20px;
      margin: 0;
    }

    /* ===== RESPONSIVE (Adjusted Sidebar) ===== */
    @media (max-width: 1024px) {
      .bus-details-grid {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 768px) {
      .buses-container {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        max-height: 150px; /* Limita la altura del sidebar en móvil */
      }

      .sidebar-title {
        display: none; /* Ocultar título en móvil para ahorrar espacio */
      }

      .buses-list {
        flex-direction: row;
        overflow-x: auto;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      }

      .bus-btn {
        min-width: 100px;
        padding: 10px 15px;
        flex-direction: column;
        text-align: center;
      }
      
      .bus-btn.active {
        border-left: none;
        border-bottom: 4px solid white;
        padding-left: 15px;
      }

      .bus-icon {
        width: 24px;
        height: 24px;
      }
      
      .bus-info-text {
          align-items: center;
      }
      
      .bus-plate {
        font-size: 14px;
      }

      .bus-route {
          display: none; /* Ocultar ruta en móvil para simplicidad */
      }

      .content-header h1 {
        font-size: 32px;
      }

      .bus-details-grid {
        padding: 20px;
        gap: 20px;
      }
    }
  `]
})
export class BusComponent implements OnInit {
  buses: BusData[] = [];
  busSeleccionado: BusData | null = null;
  // Se eliminan rutasFiltro y rutaSeleccionada ya que no se filtrará por ruta
  // rutasFiltro: string[] = []; 
  // rutaSeleccionada: string = '';

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.cargarBuses();
  }

  /**
   * Carga la lista completa de buses y selecciona el primero.
   */
  cargarBuses(): void {
    this.apiService.getBuses().subscribe({
      next: (data) => {
        this.buses = data.sort((a, b) => (a.placa > b.placa) ? 1 : -1); // Ordenar por placa
        
        // Seleccionar el primer bus si hay datos
        if (this.buses.length > 0) {
          this.seleccionarBus(this.buses[0]);
        }
      },
      error: (err) => console.error('Error al cargar buses:', err)
    });
  }

  /**
   * Establece el bus seleccionado para mostrar sus detalles.
   * @param bus El objeto BusData del bus seleccionado.
   */
  seleccionarBus(bus: BusData): void {
    this.busSeleccionado = bus;
  }
  
  // Se eliminó extraerRutas() y filtrarPorRuta()
  // ya que la nueva lógica solo necesita la lista completa y un selector individual.

  /**
   * Función mock para obtener el nombre del conductor.
   * @param bus El objeto BusData.
   * @returns El nombre del conductor.
   */
  getNombreConductor(bus: BusData): string {
    // Lógica para obtener el conductor (puede ser 'bus.conductor?.nombre' si existiera)
    return 'Jose De La Torre'; 
  }

  /**
   * Verifica si el bus está en estado 'Activo'.
   * @param bus El objeto BusData a verificar.
   * @returns true si el estado es 'Activo', false en caso contrario.
   */
  esBusActivo(bus: BusData | null): boolean {
    return bus?.estado.nombre_estado === 'Activo';
  }
}