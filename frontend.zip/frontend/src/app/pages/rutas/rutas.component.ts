import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, RutaData } from '../../services/api.service';
import { Router } from '@angular/router';
import { HeaderComponent } from '../../global/header/header.component';
import { FooterComponent } from '../../global/footer/footer.component';
import { SafeResourceUrl } from '@angular/platform-browser';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-rutas',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  template: `
    <app-header></app-header>

    <div class="rutas-container">
      <!-- Lado izquierdo: listado de rutas -->
      <div class="lista-rutas">
        <h2>Rutas disponibles</h2>
        <div
          *ngFor="let ruta of rutas"
          class="tarjeta-ruta"
          [class.activa]="rutaSeleccionada?.id === ruta.id"
          (click)="seleccionarRuta(ruta)"
        >
          <h3>{{ ruta.nombre_ruta }}</h3>
        </div>
      </div>

      <!-- Lado derecho: mapa y detalles -->
      <div class="detalle-ruta" *ngIf="rutaSeleccionada">
        <h2>{{ rutaSeleccionada.nombre_ruta }}</h2>
        <p><strong>Origen:</strong> {{ rutaSeleccionada.inicio_ruta }}</p>
        <p><strong>Destino:</strong> {{ rutaSeleccionada.fin_ruta }}</p>
        <p><strong>Descripción:</strong> {{ rutaSeleccionada.descripcion }}</p>

        <div class="mapa">
          <div class="mapa-place-holder">
            <div class="mapa-cover-jiji"></div>
            <iframe
              width="100%"
              height="300"
              frameborder="0"
              style="border:0"
              [src]="mapaSanitizado"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>

    <app-footer></app-footer>
  `,
  styles: [
    `
      .rutas-container {
        display: flex;
        padding: 2rem;
        gap: 2rem;
        align-items: flex-start;
      }

      /* Columna izquierda */
      .lista-rutas {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.6rem;
        flex: 0 0 220px;
      }

      .lista-rutas h2 {
        text-align: center;
        color: #007a9c;
        margin-bottom: 1rem;
        font-size: 1.2rem;
      }

      /* Tarjetas pequeñas celestes */
      .tarjeta-ruta {
        background-color: #00bcd4;
        color: white;
        font-weight: 600;
        border-radius: 15px;
        padding: 2rem;
        width: 100%;
        text-align: center;
        cursor: pointer;
        transition: background-color 0.2s ease, transform 0.1s ease;
      }

      .tarjeta-ruta:hover {
        background-color: #00acc1;
        transform: scale(1.03);
      }

      .tarjeta-ruta.activa {
        background-color: #0097a7;
        border: 2px solid #007a9c;
      }

      .tarjeta-ruta h3 {
        margin: 0;
        font-size: 0.95rem;
      }

      /* Columna derecha */
      .detalle-ruta {
        flex: 1;
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      }

      .detalle-ruta h2 {
        color: #003366;
        margin-bottom: 0.5rem;
      }

      .detalle-ruta p {
        margin: 0.25rem 0;
        font-size: 0.95rem;
      }

      .mapa {
        margin-top: 1rem;
        border-radius: 8px;
        overflow: hidden;
      }

      .mapa-place-holder {
  width: 90%;
  max-width: 1000px;
  height: 450px;
  margin: 20px auto;
  background-color: #e0f7fa;
  border: 3px solid #00bcd4;
  border-radius: 12px;
  box-shadow: inset 0 0 10px rgba(0, 188, 212, 0.2);
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  color: #00bcd4;
}
.mapa-place-holder iframe {
  width: 100%; /* Ocupa todo el ancho del div */
  height: 100%; /* Ocupa todo el alto del div */

}

.mapa-cover-jiji {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 60px;
  background-color: #00bcd4;
  z-index: 10;
}   

      @media (max-width: 768px) {
        .rutas-container {
          flex-direction: column;
        }

        .lista-rutas {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
        }

        .tarjeta-ruta {
          width: 100px;
          margin: 0.3rem;
        }

        .detalle-ruta {
          width: 100%;
        }
      }
    `,
  ],
})
export class RutasComponent implements OnInit {
  rutas: RutaData[] = [];
  rutaSeleccionada: RutaData | null = null;

  mapaSanitizado: SafeResourceUrl | null = null;
  constructor(
    private apiService: ApiService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.cargarRutas();
  }

  /** 🔹 Carga todas las rutas desde el backend */
  cargarRutas(): void {
    this.apiService.getRutas().subscribe({
      next: (data) => (this.rutas = data),
      error: (err) => console.error('Error cargando rutas', err),
    });
  }

  /** 🔹 Muestra la ruta seleccionada y su mapa */
  seleccionarRuta(ruta: RutaData): void {
    this.rutaSeleccionada = ruta;
    this.mapaSanitizado = this.sanitizer.bypassSecurityTrustResourceUrl(
      ruta.mapa as string
    );
  }
}
