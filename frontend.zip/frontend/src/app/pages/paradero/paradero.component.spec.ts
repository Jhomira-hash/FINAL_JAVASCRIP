import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParaderoComponent } from './paradero.component';

describe('ParaderoComponent', () => {
  let component: ParaderoComponent;
  let fixture: ComponentFixture<ParaderoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParaderoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParaderoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
