import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, ParaderoData } from '../../services/api.service';
import { HeaderComponent } from '../../global/header/header.component';
import { FooterComponent } from '../../global/footer/footer.component';

@Component({
  selector: 'app-paradero',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  template: `
    <app-header></app-header>

    <div class="container py-5">
      <!-- 🔹 Título -->
      <div class="text-center mb-5">
        <h1 class="display-5 fw-bold ">
          🏙️ Puntos de Referencia
        </h1>
        <p class="text-muted">Selecciona una categoría para ver los paraderos relacionados</p>
      </div>

      <!-- 🔹 Barra de tipos de entidad (tarjetas celestes con íconos) -->
      <div class="d-flex flex-wrap justify-content-center gap-3 mb-4">
        <div
          *ngFor="let tipo of tiposEntidad"
          class="tipo-card text-center p-3"
          [class.activo]="tipo === tipoSeleccionado"
          (click)="seleccionarTipo(tipo)"
        >
          <div class="icono mb-2">
            <i *ngIf="tipo === 'Institución Educativa'" class="bi bi-mortarboard-fill"></i>
            <i *ngIf="tipo === 'Centro Médico'" class="bi bi-hospital-fill"></i>
            <i *ngIf="tipo === 'Centro Comercial'" class="bi bi-shop"></i>
            <i *ngIf="tipo === 'Todos'" class="bi bi-globe"></i>
          </div>

          <!-- ✅ Solo mostrar el texto cuando está seleccionado -->
          <div *ngIf="tipo === tipoSeleccionado" class="nombre-tipo">
            {{ tipo }}
          </div>
        </div>
      </div>

      <!-- 🔹 Lista de paraderos -->
      <div class="row g-4 justify-content-center">
        <div class="col-12 col-sm-6 col-lg-4 col-xl-3" *ngFor="let p of paraderosFiltrados">
          <div class="card h-100 shadow-sm card-hover">
            <img
              [src]="obtenerImagen(p.tipoEntidad.nombre_entidad)"
              class="card-img-top"
              alt="{{ p.nombre_paradero }}"
            />
            <div class="card-body">
              <h5 class="card-title fw-bold text-dark">{{ p.nombre_paradero }}</h5>
              <p class="text-muted mb-2">
                <i class="bi bi-geo-alt-fill text-primary me-2"></i>{{ p.ubicacion }}
              </p>
              <p class="text-muted mb-2">
                <i class="bi bi-building text-secondary me-2"></i>{{ p.tipoEntidad.nombre_entidad }}
              </p>
              <p class="text-muted">
                <i class="bi bi-bus-front-fill text-info me-2"></i><strong>Rutas:</strong> 3, 5, 7
              </p>
            </div>
          </div>
        </div>

        <!-- Si no hay resultados -->
        <div class="col-12" *ngIf="paraderosFiltrados.length === 0">
          <div class="alert alert-info text-center">
            <i class="bi bi-info-circle me-2"></i>No se encontraron paraderos en esta categoría.
          </div>
        </div>
      </div>
    </div>

    <app-footer></app-footer>
  `,
  styles: [`
    /* 🔹 Estilo general */
    .tipo-card {
      background: #e3f2fd;
      border-radius: 12px;
      cursor: pointer;
      width: 100px;
      height: 100px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      color: #00bcd4;
    }

    .tipo-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    }

    .tipo-card.activo {
      background: #00bcd4;
      color: white;
      transform: scale(1.05);
    }

    .tipo-card .icono {
      font-size: 2rem;
      line-height: 1;
    }

    .tipo-card .nombre-tipo {
      font-weight: 600;
      font-size: 0.9rem;
      margin-top: 0.25rem;
    }

    /* 🔹 Tarjetas de paraderos */
    .card {
      border: none;
      border-radius: 10px;
      overflow: hidden;
      transition: all 0.3s ease;
    }

    .card-hover:hover {
      transform: translateY(-6px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
    }

    .card-img-top {
      height: 180px;
      object-fit: cover;
    }

    .display-5 {
      font-size: 2.2rem;
    }

    @media (max-width: 576px) {
      .tipo-card {
        width: 80px;
        height: 80px;
      }
      .tipo-card .icono {
        font-size: 1.6rem;
      }
    }
  `]
})
export class ParaderoComponent implements OnInit {
  paraderos: ParaderoData[] = [];
  tiposEntidad: string[] = [];
  tipoSeleccionado: string = 'Todos';

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.apiService.getParaderos().subscribe((data) => {
      this.paraderos = data;
      this.tiposEntidad = [
        'Todos',
        ...Array.from(new Set(data.map(p => p.tipoEntidad.nombre_entidad)))
      ];
    });
  }

  /** ✅ Filtrado dinámico */
  get paraderosFiltrados(): ParaderoData[] {
    if (this.tipoSeleccionado === 'Todos') return this.paraderos;
    return this.paraderos.filter(
      p => p.tipoEntidad.nombre_entidad === this.tipoSeleccionado
    );
  }

  seleccionarTipo(tipo: string): void {
    this.tipoSeleccionado = tipo;
  }

  obtenerImagen(tipo: string): string {
    switch (tipo) {
      case 'Institución Educativa':
        return '../../../assets/img/educativa.jpg';
      case 'Centro Médico':
        return '../../../assets/img/hospital.jpg';
      case 'Centro Comercial':
        return '../../../assets/img/comercial.jpg';
      default:
        return '../../../assets/img/default.jpg';
    }
  }
}
